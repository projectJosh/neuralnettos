#!/bin/bash
# NBPart1 - you wanted a program named this, so here it is. Runs main.py with NaiveBayes as the second argument

python main.py $1 NaiveBayes $2